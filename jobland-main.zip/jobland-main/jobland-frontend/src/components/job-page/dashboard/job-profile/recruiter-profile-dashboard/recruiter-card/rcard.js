import React from 'react'
import google from "../../../../../../assets/google-color-icon.svg"
import { FaGoogle } from 'react-icons/fa'

export default function RecruiterCard() {
  return (
    <>
<div className='flex place-content-evenly py-8 mx-12 text-xl p-5 font-semibold'>
        <span>1.</span>
        <span className=' flex ml-12'>
            Harkaran Singh</span>
        <span className='pl-10'>Software Developer</span>
        <span className='ml-5'>12/12/2023</span>
        <span className='ml-10'>Approved</span>
    </div>

    </>
  )
}
